class MarketADT:
    def __init__(self):
        self.companies = []
        self.basic = dict()
        self.active_offers = dict()
        self.ais = []

    def get_basic(self):
        pass

    def add_ais(self, ais):
        pass

    def calculate(self):
        pass
