import random
from source.training_data import generate


class AI:
    def __init__(self, market, weights=None):
        self.stocks = dict()
        for each in market.keys():
            self.stocks[each] = 0
        self.money = 8000
        if not weights:
            self._weights = [random.random() for i in range(30)]
        else:
            self._weights = weights

    def train(self, training_input, training_output, loop):
        """
        Training script of AI
        :param training_input: list - training input sequences
        :param training_output: list - training output sequences
        :param loop: int - number of times to repeat training process
        """
        for i in range(loop):
            for j in range(len(training_input)):
                prediction = self._feedforward(training_input[j])
                if prediction != 0:
                    self._change_weights(prediction, training_output[j])
        print("Training finished!")

    def predict(self, market):
        """
        Makes prediction for 10 days
        :param market: dict - current data about market
        :return: number - percent of change for price
        """
        prediction = dict()
        for company in market.keys():
            prediction[company] = self._feedforward(market[company]) * 200 / (float(market[company][-1]) / 100) - 100
        return prediction

    def _feedforward(self, info):
        input_neurons = info
        z = 0
        for i in range(len(self._weights)):
            z += float(input_neurons[i])/200 * self._weights[i]
        if z <= 0:
            return 0
        else:
            return z

    def _change_weights(self, prediction, actual):
        print("Error " + str(prediction*200-actual))
        for index in range(len(self._weights)):
            change = (actual/200-prediction)*self._weights[index]
            self._weights[index] += 10 ** (-4) * change

    def choice(self, market):
        """
        Generates choices for AI
        :param market: dict - current data about market
        :return: list - data about choice of AI
        """
        prediction = self.predict(market)
        operation = dict()
        for company in prediction.keys():
            operation[company] = [self, 0, 0]
            if prediction[company] >= 20:
                quant = random.randint(50, 100)
                price = round(float(market[company][-1]) * random.randint(120, 130) * 0.01)
                if self.money >= price * quant:
                    operation[company] = [self, price, quant]
                elif price <= self.money:
                    operation[company] = [self, price, self.money // price]
            elif prediction[company] >= 10:
                quant = random.randint(25, 75)
                price = round(float(market[company][-1])*(random.randint(110, 130)*0.01))
                if self.money >= price * quant:
                    operation[company] = [self, price, quant]
                elif price <= self.money:
                    operation[company] = [self, price, self.money // price]
            elif prediction[company] >= 5:
                quant = random.randint(-(self.stocks[company] // 8), 50)
                price = round(float(market[company][-1])*(random.randint(100, 120)*0.01))
                if self.money >= price * quant:
                    operation[company] = [self, price, quant]
                elif price <= self.money:
                    operation[company] = [self, price, self.money // price]
            elif prediction[company] >= 2.5:
                quant = random.randint(-(self.stocks[company] // 8), 25)
                price = round(float(market[company][-1])*(random.randint(100, 120)*0.01))
                if self.money >= price * quant:
                    operation[company] = [self, price, quant]
                elif price <= self.money:
                    operation[company] = [self, price, self.money // price]
            elif prediction[company] >= 1:
                quant = random.randint(-(self.stocks[company] // 6), 10)
                price = round(float(market[company][-1])*(random.randint(90, 110)*0.01))
                if self.money >= price * quant:
                    operation[company] = [self, price, quant]
                elif price <= self.money:
                    operation[company] = [self, price, self.money // price]
            elif prediction[company] >= 0.5:
                quant = random.randint(-(self.stocks[company] // 4), 10)
                price = round(float(market[company][-1]) * (random.randint(90, 110) * 0.01))
                if self.money >= price * quant:
                    operation[company] = [self, price, quant]
                elif price <= self.money:
                    operation[company] = [self, price, self.money // price]
            elif prediction[company] >= 0:
                operation[company] = [self, round(float(market[company][-1])*random.randint(100, 120)*0.01, 2), -(self.stocks[company] // 6)]
            elif prediction[company] >= -0.5:
                operation[company] = [self, round(float(market[company][-1])*random.randint(90, 110)*0.01, 2), -(self.stocks[company] // 6)]
            elif prediction[company] >= -1:
                operation[company] = [self, round(float(market[company][-1])*random.randint(90, 110)*0.01, 2), -(self.stocks[company] // 5)]
            elif prediction[company] >= -1.5:
                operation[company] = [self, round(float(market[company][-1])*random.randint(90, 100)*0.01, 2), -(self.stocks[company] // 4)]
            elif prediction[company] >= -2.5:
                operation[company] = [self, round(float(market[company][-1])*random.randint(89, 100)*0.01, 2), -(self.stocks[company] // 3)]
            elif prediction[company] >= -5:
                operation[company] = [self, round(float(market[company][-1])*random.randint(80, 90)*0.01, 2), -(self.stocks[company] // 2)]
            else:
                operation[company] = [self, round(float(market[company][-1])*random.randint(80, 90)*0.01, 2), -self.stocks[company]]
        return operation


def generate_ai():
    """
    Generates set of AIs
    :return: list - set of AIs
    """
    ais = []
    prices, results = generate()
    for n in range(50):
        indexes = []
        for m in range(3):
            indexes.append(random.randint(0, 23))
        ais.append(AI({'AAPL': [], 'AMD': [], 'AMZN': [], "INTC": [], "MSFT": [], "CSCO": [], "GPRO": [], "NVDA": [], "FB": [], "COKE": [], "WIX": [], "TSLA": [], "NTES": [], "MU": [], "ROKU": [], "YAHOY": [], "UBSFF": [], "NDAQ": [], "NICE": [], "WMT": [], "BABA": [], "GOOG": [], "IBM": []}))
    for each in ais:
        each.train([prices[indexes[0]], prices[indexes[1]], prices[indexes[2]]], [results[indexes[0]], results[indexes[1]], results[indexes[2]]], 1000 * random.randint(2, 10))
    print("Generation finished!")
    return ais
