from distutils.core import setup

setup(name='StickSimulator',
      version='1.0',
      description='Course work. Stock simulator',
      author='Marko Zahartovskyi, Yana Kurlyak',
      author_email='zahart76@gmail.com',
      packages=['source'],
      data_files=[('images', ['greybackground.jpg'])]
     )